﻿declare module 'quill' {
    const Quill: any;
    export default Quill;
}
