﻿import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Instruks } from './models/instruks.model';

@Injectable({ providedIn: 'root' })
export class InstruksService {
  private readonly baseUrl = '/api/instruks';

  constructor(private http: HttpClient) {}

  getAll(): Observable<Instruks[]> {
    return this.http.get<Instruks[]>(this.baseUrl);
  }

  getById(id: number): Observable<Instruks> {
    return this.http.get<Instruks>(`${this.baseUrl}/${id}`);
  }

  getByCategory(categoryId: number): Observable<Instruks[]> {
    return this.http.get<Instruks[]>(`${this.baseUrl}?categoryId=${categoryId}`);
  }

  create(dto: Partial<Instruks>): Observable<void> {
    return this.http.post<void>(this.baseUrl, dto);
  }

  update(id: number, dto: Partial<Instruks>): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${id}`, dto);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}
