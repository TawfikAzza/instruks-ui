﻿export interface Category {
  id: number;
  name: string;
}
export interface CategoryDto {
  id: number;
  name: string;
}
