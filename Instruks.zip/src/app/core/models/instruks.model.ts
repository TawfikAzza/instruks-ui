﻿export interface Instruks {
  id: number;
  title: string;
  description: string;
  content: string;
  createdAt: string;
  updatedAt: string;
  categoryId: number;
}
